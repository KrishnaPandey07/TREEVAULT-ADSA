from pydantic import BaseModel, Field, field_validator
from typing import Optional, List, Dict, Any

class StudentCreate(BaseModel):
    id: int = Field(..., gt=0, description="Student ID (positive integer)")
    name: str = Field(..., min_length=1, max_length=100, description="Student name")
    marks: float = Field(..., ge=0, le=100, description="Marks (0-100)")
    
    @field_validator('name')
    @classmethod
    def name_must_not_be_blank(cls, v):
        if not v.strip():
            raise ValueError('Name cannot be blank')
        return v.strip()

class StudentResponse(BaseModel):
    id: int
    name: str
    marks: float

class InsertResponse(BaseModel):
    success: bool
    message: str
    student: StudentResponse
    rotations: List[str]
    tree: Optional[Dict[str, Any]] = None

class SearchResponse(BaseModel):
    found: bool
    student: Optional[StudentResponse] = None
    search_path: List[int] = []
    message: str

class DeleteResponse(BaseModel):
    success: bool
    message: str
    student: Optional[StudentResponse] = None
    rotations: List[str] = []
    tree: Optional[Dict[str, Any]] = None

class TreeStatsResponse(BaseModel):
    count: int
    height: int
    is_balanced: bool
    total_rotations: int

class TraversalResponse(BaseModel):
    order: str
    students: List[StudentResponse]

class ErrorResponse(BaseModel):
    detail: str
