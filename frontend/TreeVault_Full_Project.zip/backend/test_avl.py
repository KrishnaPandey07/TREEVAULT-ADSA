import pytest
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))
from avl_tree import Student, AVLNode, AVLTree


class TestAVLBasic:
    """Test basic AVL tree operations."""
    
    def setup_method(self):
        self.tree = AVLTree()
    
    def test_empty_tree(self):
        assert self.tree.root is None
        assert self.tree.get_all_students() == []
        assert self.tree.get_tree_dict() is None
        stats = self.tree.get_stats()
        assert stats['count'] == 0
        assert stats['height'] == 0
    
    def test_insert_single(self):
        s = Student(10, 'Aarav', 85)
        success, rotations = self.tree.insert_student(s)
        assert success is True
        assert rotations == []
        assert self.tree.root is not None
        assert self.tree.root.student.id == 10
        assert self.tree.root.height == 1
        self.tree.validate()
    
    def test_insert_multiple_no_rotation(self):
        self.tree.insert_student(Student(20, 'B', 80))
        self.tree.insert_student(Student(10, 'A', 90))
        self.tree.insert_student(Student(30, 'C', 70))
        assert self.tree.root.student.id == 20
        assert self.tree.root.left.student.id == 10
        assert self.tree.root.right.student.id == 30
        self.tree.validate()
    
    def test_duplicate_id(self):
        self.tree.insert_student(Student(10, 'A', 85))
        with pytest.raises(ValueError):
            self.tree.insert_student(Student(10, 'B', 90))
        self.tree.validate()


class TestAVLRotations:
    """Test all four rotation cases."""
    
    def setup_method(self):
        self.tree = AVLTree()
    
    def test_ll_rotation(self):
        """Insert 30, 20, 10 -> LL case -> Right Rotation."""
        self.tree.insert_student(Student(30, 'C', 70))
        self.tree.insert_student(Student(20, 'B', 80))
        success, rotations = self.tree.insert_student(Student(10, 'A', 90))
        # After rotation: 20 is root, 10 left, 30 right
        assert self.tree.root.student.id == 20
        assert self.tree.root.left.student.id == 10
        assert self.tree.root.right.student.id == 30
        assert any('LL' in r or 'Right Rotation' in r for r in rotations)
        self.tree.validate()
    
    def test_rr_rotation(self):
        """Insert 10, 20, 30 -> RR case -> Left Rotation."""
        self.tree.insert_student(Student(10, 'A', 90))
        self.tree.insert_student(Student(20, 'B', 80))
        success, rotations = self.tree.insert_student(Student(30, 'C', 70))
        # After rotation: 20 is root, 10 left, 30 right
        assert self.tree.root.student.id == 20
        assert self.tree.root.left.student.id == 10
        assert self.tree.root.right.student.id == 30
        assert any('RR' in r or 'Left Rotation' in r for r in rotations)
        self.tree.validate()
    
    def test_lr_rotation(self):
        """Insert 30, 10, 20 -> LR case -> Left-Right Rotation."""
        self.tree.insert_student(Student(30, 'C', 70))
        self.tree.insert_student(Student(10, 'A', 90))
        success, rotations = self.tree.insert_student(Student(20, 'B', 80))
        # After rotation: 20 is root, 10 left, 30 right
        assert self.tree.root.student.id == 20
        assert self.tree.root.left.student.id == 10
        assert self.tree.root.right.student.id == 30
        assert any('LR' in r or 'Left-Right' in r for r in rotations)
        self.tree.validate()
    
    def test_rl_rotation(self):
        """Insert 10, 30, 20 -> RL case -> Right-Left Rotation."""
        self.tree.insert_student(Student(10, 'A', 90))
        self.tree.insert_student(Student(30, 'C', 70))
        success, rotations = self.tree.insert_student(Student(20, 'B', 80))
        # After rotation: 20 is root, 10 left, 30 right
        assert self.tree.root.student.id == 20
        assert self.tree.root.left.student.id == 10
        assert self.tree.root.right.student.id == 30
        assert any('RL' in r or 'Right-Left' in r for r in rotations)
        self.tree.validate()


class TestAVLSearch:
    """Test search functionality."""
    
    def setup_method(self):
        self.tree = AVLTree()
        for sid, name, marks in [(50, 'E', 50), (30, 'C', 30), (70, 'G', 70),
                                  (20, 'B', 20), (40, 'D', 40), (60, 'F', 60), (80, 'H', 80)]:
            self.tree.insert_student(Student(sid, name, marks))
    
    def test_search_root(self):
        student, path = self.tree.search_student(50)
        assert student is not None
        assert student.id == 50
        assert 50 in path
    
    def test_search_leaf(self):
        student, path = self.tree.search_student(20)
        assert student is not None
        assert student.id == 20
        assert len(path) > 1
    
    def test_search_not_found(self):
        student, path = self.tree.search_student(999)
        assert student is None
    
    def test_search_empty_tree(self):
        empty = AVLTree()
        student, path = empty.search_student(10)
        assert student is None
        assert path == []


class TestAVLDeletion:
    """Test deletion in all cases."""
    
    def setup_method(self):
        self.tree = AVLTree()
    
    def test_delete_leaf(self):
        self.tree.insert_student(Student(20, 'B', 80))
        self.tree.insert_student(Student(10, 'A', 90))
        self.tree.insert_student(Student(30, 'C', 70))
        deleted, rotations = self.tree.delete_student(10)
        assert deleted is not None
        assert deleted.id == 10
        assert self.tree.search_student(10)[0] is None
        self.tree.validate()
    
    def test_delete_node_one_child(self):
        self.tree.insert_student(Student(20, 'B', 80))
        self.tree.insert_student(Student(10, 'A', 90))
        self.tree.insert_student(Student(30, 'C', 70))
        self.tree.insert_student(Student(25, 'D', 60))
        deleted, rotations = self.tree.delete_student(30)
        assert deleted is not None
        assert deleted.id == 30
        self.tree.validate()
    
    def test_delete_node_two_children(self):
        for sid in [50, 30, 70, 20, 40, 60, 80]:
            self.tree.insert_student(Student(sid, f'S{sid}', sid))
        deleted, rotations = self.tree.delete_student(50)
        assert deleted is not None
        assert deleted.id == 50
        # Root should change
        assert self.tree.root.student.id != 50
        self.tree.validate()
    
    def test_delete_root_single_node(self):
        self.tree.insert_student(Student(10, 'A', 90))
        deleted, rotations = self.tree.delete_student(10)
        assert deleted is not None
        assert self.tree.root is None
    
    def test_delete_root_with_children(self):
        self.tree.insert_student(Student(20, 'B', 80))
        self.tree.insert_student(Student(10, 'A', 90))
        self.tree.insert_student(Student(30, 'C', 70))
        deleted, rotations = self.tree.delete_student(20)
        assert deleted is not None
        assert deleted.id == 20
        assert self.tree.root is not None
        self.tree.validate()
    
    def test_delete_not_found(self):
        self.tree.insert_student(Student(10, 'A', 90))
        deleted, rotations = self.tree.delete_student(999)
        assert deleted is None
    
    def test_delete_from_empty(self):
        deleted, rotations = self.tree.delete_student(10)
        assert deleted is None
    
    def test_delete_causes_rotation(self):
        """Deletion that triggers rebalancing."""
        # Build a tree where deleting a node causes imbalance
        self.tree.insert_student(Student(20, 'B', 80))
        self.tree.insert_student(Student(10, 'A', 90))
        self.tree.insert_student(Student(30, 'C', 70))
        self.tree.insert_student(Student(25, 'D', 60))
        # Delete 10 - right subtree heavier, may need rotation
        deleted, rotations = self.tree.delete_student(10)
        assert deleted is not None
        self.tree.validate()


class TestAVLTraversals:
    """Test traversal orders."""
    
    def setup_method(self):
        self.tree = AVLTree()
        for sid in [50, 30, 70, 20, 40]:
            self.tree.insert_student(Student(sid, f'S{sid}', sid))
    
    def test_inorder(self):
        students = self.tree.get_all_students()
        ids = [s.id for s in students]
        assert ids == sorted(ids)
    
    def test_preorder(self):
        students = self.tree.preorder(self.tree.root)
        assert len(students) == 5
        # Root should be first
        assert students[0].id == self.tree.root.student.id
    
    def test_postorder(self):
        students = self.tree.postorder(self.tree.root)
        assert len(students) == 5
        # Root should be last
        assert students[-1].id == self.tree.root.student.id


class TestAVLHeightBalance:
    """Test height and balance factor calculations."""
    
    def setup_method(self):
        self.tree = AVLTree()
    
    def test_single_node_height(self):
        self.tree.insert_student(Student(10, 'A', 90))
        assert self.tree.root.height == 1
    
    def test_height_after_insertions(self):
        for sid in [50, 30, 70, 20, 40, 60, 80]:
            self.tree.insert_student(Student(sid, f'S{sid}', sid))
        # With 7 balanced nodes, height should be 3
        assert self.tree.root.height == 3
        self.tree.validate()
    
    def test_balance_maintained_many_insertions(self):
        """Insert many nodes and verify AVL invariants hold."""
        import random
        random.seed(42)
        ids = random.sample(range(1, 1000), 100)
        for sid in ids:
            self.tree.insert_student(Student(sid, f'S{sid}', sid % 100))
            self.tree.validate()
    
    def test_balance_maintained_many_deletions(self):
        """Insert then delete many nodes, verify invariants."""
        import random
        random.seed(42)
        ids = random.sample(range(1, 500), 50)
        for sid in ids:
            self.tree.insert_student(Student(sid, f'S{sid}', sid % 100))
        random.shuffle(ids)
        for sid in ids:
            self.tree.delete_student(sid)
            self.tree.validate()
        assert self.tree.root is None


class TestAVLTreeDict:
    """Test tree serialization."""
    
    def setup_method(self):
        self.tree = AVLTree()
    
    def test_empty_tree_dict(self):
        assert self.tree.get_tree_dict() is None
    
    def test_single_node_dict(self):
        self.tree.insert_student(Student(10, 'Aarav', 85))
        d = self.tree.get_tree_dict()
        assert d['id'] == 10
        assert d['name'] == 'Aarav'
        assert d['marks'] == 85
        assert d['height'] == 1
        assert d['balance_factor'] == 0
        assert d['left'] is None
        assert d['right'] is None
    
    def test_tree_dict_structure(self):
        for sid in [20, 10, 30]:
            self.tree.insert_student(Student(sid, f'S{sid}', sid))
        d = self.tree.get_tree_dict()
        assert d['id'] == 20
        assert d['left']['id'] == 10
        assert d['right']['id'] == 30


class TestAVLStats:
    """Test statistics."""
    
    def setup_method(self):
        self.tree = AVLTree()
    
    def test_empty_stats(self):
        stats = self.tree.get_stats()
        assert stats['count'] == 0
        assert stats['height'] == 0
        assert stats['is_balanced'] is True
        assert stats['total_rotations'] == 0
    
    def test_stats_after_rotation(self):
        self.tree.insert_student(Student(30, 'C', 70))
        self.tree.insert_student(Student(20, 'B', 80))
        self.tree.insert_student(Student(10, 'A', 90))
        stats = self.tree.get_stats()
        assert stats['count'] == 3
        assert stats['total_rotations'] >= 1
        assert stats['is_balanced'] is True


class TestAVLClear:
    """Test clear functionality."""
    
    def test_clear(self):
        tree = AVLTree()
        for sid in [50, 30, 70]:
            tree.insert_student(Student(sid, f'S{sid}', sid))
        tree.clear()
        assert tree.root is None
        assert tree.get_all_students() == []
        assert tree.total_rotations == 0


class TestAVLEdgeCases:
    """Additional edge cases."""
    
    def setup_method(self):
        self.tree = AVLTree()
        
    def test_insert_negative_id(self):
        """Test negative IDs, assuming supported."""
        self.tree.insert_student(Student(-10, 'Neg', 50))
        assert self.tree.root.student.id == -10
        self.tree.validate()

    def test_insert_large_number(self):
        """Insert extreme number."""
        self.tree.insert_student(Student(999999999, 'Huge', 100))
        assert self.tree.root.student.id == 999999999
        self.tree.validate()
