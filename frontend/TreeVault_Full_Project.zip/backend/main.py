import os
from typing import List
from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager

from avl_tree import AVLTree, Student
import database
from schemas import (
    StudentCreate, StudentResponse, InsertResponse, SearchResponse,
    DeleteResponse, TreeStatsResponse, TraversalResponse, ErrorResponse
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # On startup
    database.init_db()
    students = database.load_all_students()
    
    tree = AVLTree()
    for student in students:
        tree.insert_student(student)
        
    app.state.avl_tree = tree
    yield
    # On shutdown (nothing specific to do)

app = FastAPI(lifespan=lifespan)

frontend_url = os.getenv('FRONTEND_URL', 'http://localhost:5500')
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        frontend_url, 'http://localhost:5500', 'http://127.0.0.1:5500', 
        'http://localhost:5501', 'http://127.0.0.1:5501', 
        'http://localhost:3000', 'http://127.0.0.1:3000', 'null'
    ],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    if isinstance(exc, HTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail}
        )
    return JSONResponse(
        status_code=500,
        content={"detail": "An unexpected error occurred."}
    )

@app.post("/api/students", response_model=InsertResponse)
async def create_student(student_create: StudentCreate):
    tree: AVLTree = app.state.avl_tree
    
    student = Student(id=student_create.id, name=student_create.name, marks=student_create.marks)
    try:
        success, rotations = tree.insert_student(student)
    except ValueError:
        raise HTTPException(status_code=409, detail="Student with this ID already exists.")
        
    database.save_student(student)
    
    return InsertResponse(
        success=True,
        message="Student added successfully.",
        student=StudentResponse(id=student.id, name=student.name, marks=student.marks),
        rotations=rotations,
        tree=tree.get_tree_dict()
    )

@app.get("/api/students", response_model=List[StudentResponse])
async def get_all_students():
    tree: AVLTree = app.state.avl_tree
    students = tree.get_all_students()
    return [StudentResponse(id=s.id, name=s.name, marks=s.marks) for s in students]

@app.get("/api/students/{student_id}", response_model=SearchResponse)
async def search_student(student_id: int):
    tree: AVLTree = app.state.avl_tree
    student, path = tree.search_student(student_id)
    
    if student is None:
        raise HTTPException(status_code=404, detail="Student not found.")
        
    return SearchResponse(
        found=True,
        student=StudentResponse(id=student.id, name=student.name, marks=student.marks),
        search_path=path,
        message="Student found."
    )

@app.delete("/api/students/{student_id}", response_model=DeleteResponse)
async def delete_student(student_id: int):
    tree: AVLTree = app.state.avl_tree
    deleted_student, rotations = tree.delete_student(student_id)
    
    if deleted_student is None:
        raise HTTPException(status_code=404, detail="Student not found.")
        
    database.remove_student(student_id)
    
    return DeleteResponse(
        success=True,
        message="Student deleted successfully.",
        student=StudentResponse(id=deleted_student.id, name=deleted_student.name, marks=deleted_student.marks),
        rotations=rotations,
        tree=tree.get_tree_dict()
    )

@app.get("/api/tree")
async def get_tree():
    tree: AVLTree = app.state.avl_tree
    return tree.get_tree_dict()

@app.get("/api/tree/traversal/{order}", response_model=TraversalResponse)
async def traverse_tree(order: str):
    tree: AVLTree = app.state.avl_tree
    
    if order == 'inorder':
        students = tree.inorder(tree.root)
    elif order == 'preorder':
        students = tree.preorder(tree.root)
    elif order == 'postorder':
        students = tree.postorder(tree.root)
    else:
        raise HTTPException(status_code=400, detail="Invalid traversal order. Must be 'inorder', 'preorder', or 'postorder'.")
        
    return TraversalResponse(
        order=order,
        students=[StudentResponse(id=s.id, name=s.name, marks=s.marks) for s in students]
    )

@app.get("/api/tree/stats", response_model=TreeStatsResponse)
async def get_stats():
    tree: AVLTree = app.state.avl_tree
    stats = tree.get_stats()
    return TreeStatsResponse(**stats)

@app.delete("/api/clear")
async def clear_all():
    tree: AVLTree = app.state.avl_tree
    tree.clear()
    database.clear_all_students()
    return {"message": "Tree and database cleared successfully."}

# Mount frontend directory for seamless cloud deployment (Render, Railway, etc.)
frontend_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend")
if os.path.exists(frontend_dir):
    app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="frontend")

