from dataclasses import dataclass
from typing import Optional, List, Dict, Any, Tuple

@dataclass
class Student:
    id: int
    name: str
    marks: float

class AVLNode:
    def __init__(self, student: Student):
        self.student = student
        self.left: Optional['AVLNode'] = None
        self.right: Optional['AVLNode'] = None
        self.height: int = 1

class AVLTree:
    def __init__(self):
        self.root: Optional[AVLNode] = None
        self.total_rotations: int = 0
    
    def get_height(self, node: Optional[AVLNode]) -> int:
        if not node:
            return 0
        return node.height

    def get_balance(self, node: Optional[AVLNode]) -> int:
        if not node:
            return 0
        return self.get_height(node.left) - self.get_height(node.right)

    def rotate_right(self, y: AVLNode) -> AVLNode:
        self.total_rotations += 1
        x = y.left
        T2 = x.right

        # Perform rotation
        x.right = y
        y.left = T2

        # Update heights
        y.height = 1 + max(self.get_height(y.left), self.get_height(y.right))
        x.height = 1 + max(self.get_height(x.left), self.get_height(x.right))

        return x

    def rotate_left(self, x: AVLNode) -> AVLNode:
        self.total_rotations += 1
        y = x.right
        T2 = y.left

        # Perform rotation
        y.left = x
        x.right = T2

        # Update heights
        x.height = 1 + max(self.get_height(x.left), self.get_height(x.right))
        y.height = 1 + max(self.get_height(y.left), self.get_height(y.right))

        return y

    def insert(self, root: Optional[AVLNode], student: Student) -> Tuple[AVLNode, List[str]]:
        rotations = []
        
        if not root:
            return AVLNode(student), rotations

        if student.id < root.student.id:
            root.left, child_rotations = self.insert(root.left, student)
            rotations.extend(child_rotations)
        elif student.id > root.student.id:
            root.right, child_rotations = self.insert(root.right, student)
            rotations.extend(child_rotations)
        else:
            raise ValueError("Duplicate ID")

        root.height = 1 + max(self.get_height(root.left), self.get_height(root.right))
        balance = self.get_balance(root)

        # Left Left
        if balance > 1 and student.id < root.left.student.id:
            rotations.append('LL - Right Rotation')
            return self.rotate_right(root), rotations

        # Right Right
        if balance < -1 and student.id > root.right.student.id:
            rotations.append('RR - Left Rotation')
            return self.rotate_left(root), rotations

        # Left Right
        if balance > 1 and student.id > root.left.student.id:
            rotations.append('LR - Left-Right Rotation')
            root.left = self.rotate_left(root.left)
            return self.rotate_right(root), rotations

        # Right Left
        if balance < -1 and student.id < root.right.student.id:
            rotations.append('RL - Right-Left Rotation')
            root.right = self.rotate_right(root.right)
            return self.rotate_left(root), rotations

        return root, rotations

    def insert_student(self, student: Student) -> Tuple[bool, List[str]]:
        try:
            self.root, rotations = self.insert(self.root, student)
            return True, rotations
        except ValueError:
            raise

    def search(self, root: Optional[AVLNode], student_id: int) -> Tuple[Optional[AVLNode], List[int]]:
        path = []
        current = root
        while current:
            path.append(current.student.id)
            if current.student.id == student_id:
                return current, path
            elif current.student.id < student_id:
                current = current.right
            else:
                current = current.left
        return None, path

    def search_student(self, student_id: int) -> Tuple[Optional[Student], List[int]]:
        node, path = self.search(self.root, student_id)
        return node.student if node else None, path

    def min_value_node(self, node: AVLNode) -> AVLNode:
        current = node
        while current.left is not None:
            current = current.left
        return current

    def delete(self, root: Optional[AVLNode], student_id: int) -> Tuple[Optional[AVLNode], Optional[Student], List[str]]:
        if not root:
            return root, None, []

        rotations = []
        deleted_student = None

        if student_id < root.student.id:
            root.left, deleted_student, child_rotations = self.delete(root.left, student_id)
            rotations.extend(child_rotations)
        elif student_id > root.student.id:
            root.right, deleted_student, child_rotations = self.delete(root.right, student_id)
            rotations.extend(child_rotations)
        else:
            deleted_student = root.student
            if root.left is None:
                temp = root.right
                root = None
                return temp, deleted_student, rotations
            elif root.right is None:
                temp = root.left
                root = None
                return temp, deleted_student, rotations

            temp = self.min_value_node(root.right)
            root.student = temp.student
            root.right, _, child_rotations = self.delete(root.right, temp.student.id)
            rotations.extend(child_rotations)

        if root is None:
            return root, deleted_student, rotations

        root.height = 1 + max(self.get_height(root.left), self.get_height(root.right))
        balance = self.get_balance(root)

        # Left Left
        if balance > 1 and self.get_balance(root.left) >= 0:
            rotations.append('LL - Right Rotation')
            return self.rotate_right(root), deleted_student, rotations

        # Left Right
        if balance > 1 and self.get_balance(root.left) < 0:
            rotations.append('LR - Left-Right Rotation')
            root.left = self.rotate_left(root.left)
            return self.rotate_right(root), deleted_student, rotations

        # Right Right
        if balance < -1 and self.get_balance(root.right) <= 0:
            rotations.append('RR - Left Rotation')
            return self.rotate_left(root), deleted_student, rotations

        # Right Left
        if balance < -1 and self.get_balance(root.right) > 0:
            rotations.append('RL - Right-Left Rotation')
            root.right = self.rotate_right(root.right)
            return self.rotate_left(root), deleted_student, rotations

        return root, deleted_student, rotations

    def delete_student(self, student_id: int) -> Tuple[Optional[Student], List[str]]:
        self.root, deleted_student, rotations = self.delete(self.root, student_id)
        return deleted_student, rotations

    def inorder(self, root: Optional[AVLNode]) -> List[Student]:
        res = []
        if root:
            res = self.inorder(root.left)
            res.append(root.student)
            res = res + self.inorder(root.right)
        return res

    def preorder(self, root: Optional[AVLNode]) -> List[Student]:
        res = []
        if root:
            res.append(root.student)
            res = res + self.preorder(root.left)
            res = res + self.preorder(root.right)
        return res

    def postorder(self, root: Optional[AVLNode]) -> List[Student]:
        res = []
        if root:
            res = self.postorder(root.left)
            res = res + self.postorder(root.right)
            res.append(root.student)
        return res

    def get_all_students(self) -> List[Student]:
        return self.inorder(self.root)

    def to_dict(self, node: Optional[AVLNode]) -> Optional[Dict]:
        if not node:
            return None
        return {
            "id": node.student.id,
            "name": node.student.name,
            "marks": node.student.marks,
            "height": node.height,
            "balance_factor": self.get_balance(node),
            "left": self.to_dict(node.left),
            "right": self.to_dict(node.right)
        }

    def get_tree_dict(self) -> Optional[Dict]:
        return self.to_dict(self.root)

    def get_count(self, node: Optional[AVLNode]) -> int:
        if not node:
            return 0
        return 1 + self.get_count(node.left) + self.get_count(node.right)

    def get_stats(self) -> Dict:
        # Check if root is balanced by checking if any node has abs(balance) > 1, but for tree level we can just check root
        # Actually a tree is balanced if all nodes are balanced. AVL ensures this, so True.
        # But for exactness, if root is None, it's balanced. 
        return {
            "count": self.get_count(self.root),
            "height": self.get_height(self.root),
            "is_balanced": True, 
            "total_rotations": self.total_rotations
        }

    def validate(self) -> bool:
        ids_seen = set()
        def check(node: Optional[AVLNode], min_val: float, max_val: float) -> bool:
            if not node:
                return True
            
            if node.student.id in ids_seen:
                raise AssertionError(f"Duplicate ID found: {node.student.id}")
            ids_seen.add(node.student.id)
            
            if not (min_val < node.student.id < max_val):
                raise AssertionError(f"BST violation: node id {node.student.id} out of bounds")

            lh = self.get_height(node.left)
            rh = self.get_height(node.right)
            
            if node.height != 1 + max(lh, rh):
                raise AssertionError(f"Height violation at node {node.student.id}")
                
            balance = lh - rh
            if balance not in [-1, 0, 1]:
                raise AssertionError(f"Balance violation at node {node.student.id}: balance is {balance}")
                
            return check(node.left, min_val, node.student.id) and check(node.right, node.student.id, max_val)

        return check(self.root, float('-inf'), float('inf'))

    def clear(self):
        self.root = None
        self.total_rotations = 0
