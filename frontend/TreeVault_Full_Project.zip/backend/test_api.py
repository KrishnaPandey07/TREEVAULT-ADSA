import os
import pytest
from fastapi.testclient import TestClient

# Ensure test DB is used
os.environ['DATABASE_URL'] = 'test_vidyavriksha.db'

import database
database.DATABASE_PATH = 'test_vidyavriksha.db'

from main import app

@pytest.fixture(autouse=True)
def clean_db():
    if os.path.exists('test_vidyavriksha.db'):
        try:
            os.remove('test_vidyavriksha.db')
        except Exception:
            pass
    database.init_db()
    database.clear_all_students()
    yield
    if os.path.exists('test_vidyavriksha.db'):
        try:
            os.remove('test_vidyavriksha.db')
        except Exception:
            pass

def test_api_crud_flow():
    with TestClient(app) as client:
        # 1. Clear database
        resp = client.delete("/api/clear")
        assert resp.status_code == 200

        # 2. Insert students
        r1 = client.post("/api/students", json={"id": 30, "name": "Aarav", "marks": 85})
        assert r1.status_code == 200
        assert r1.json()["success"] is True
        assert r1.json()["student"]["id"] == 30

        r2 = client.post("/api/students", json={"id": 20, "name": "Ananya", "marks": 92})
        assert r2.status_code == 200

        # Insert that causes LL right rotation
        r3 = client.post("/api/students", json={"id": 10, "name": "Arjun", "marks": 78})
        assert r3.status_code == 200
        data3 = r3.json()
        assert any("LL" in rot or "Right Rotation" in rot for rot in data3["rotations"])
        assert data3["tree"]["id"] == 20  # Root should become 20 after LL rotation!

        # 3. Duplicate ID test -> 409 Conflict
        dup = client.post("/api/students", json={"id": 20, "name": "Duplicate", "marks": 50})
        assert dup.status_code == 409

        # 4. Get all students (sorted by ID)
        all_resp = client.get("/api/students")
        assert all_resp.status_code == 200
        students = all_resp.json()
        assert len(students) == 3
        assert [s["id"] for s in students] == [10, 20, 30]

        # 5. Search student (with path)
        search_resp = client.get("/api/students/10")
        assert search_resp.status_code == 200
        s_data = search_resp.json()
        assert s_data["found"] is True
        assert s_data["student"]["name"] == "Arjun"
        assert 20 in s_data["search_path"]
        assert 10 in s_data["search_path"]

        # Search non-existent -> 404
        search_404 = client.get("/api/students/999")
        assert search_404.status_code == 404

        # 6. Tree structure
        tree_resp = client.get("/api/tree")
        assert tree_resp.status_code == 200
        tree = tree_resp.json()
        assert tree["id"] == 20
        assert tree["left"]["id"] == 10
        assert tree["right"]["id"] == 30

        # 7. Stats
        stats_resp = client.get("/api/tree/stats")
        assert stats_resp.status_code == 200
        stats = stats_resp.json()
        assert stats["count"] == 3
        assert stats["height"] == 2
        assert stats["is_balanced"] is True
        assert stats["total_rotations"] >= 1

        # 8. Traversals
        inorder_resp = client.get("/api/tree/traversal/inorder")
        assert inorder_resp.status_code == 200
        assert [s["id"] for s in inorder_resp.json()["students"]] == [10, 20, 30]

        preorder_resp = client.get("/api/tree/traversal/preorder")
        assert preorder_resp.status_code == 200
        assert [s["id"] for s in preorder_resp.json()["students"]] == [20, 10, 30]

        postorder_resp = client.get("/api/tree/traversal/postorder")
        assert postorder_resp.status_code == 200
        assert [s["id"] for s in postorder_resp.json()["students"]] == [10, 30, 20]

        # Invalid traversal -> 400
        bad_trav = client.get("/api/tree/traversal/invalid")
        assert bad_trav.status_code == 400

        # 9. Delete student
        del_resp = client.delete("/api/students/20")
        assert del_resp.status_code == 200
        assert del_resp.json()["success"] is True

        # Delete non-existent -> 404
        del_404 = client.delete("/api/students/999")
        assert del_404.status_code == 404

def test_persistence_across_startup():
    # Insert items in one session
    with TestClient(app) as client:
        client.delete("/api/clear")
        client.post("/api/students", json={"id": 50, "name": "Bhavya", "marks": 88})
        client.post("/api/students", json={"id": 25, "name": "Chetan", "marks": 94})
        client.post("/api/students", json={"id": 75, "name": "Divya", "marks": 91})

    # Simulate restart by creating new TestClient (triggers lifespan again)
    with TestClient(app) as client2:
        resp = client2.get("/api/students")
        assert resp.status_code == 200
        students = resp.json()
        assert len(students) == 3
        assert [s["id"] for s in students] == [25, 50, 75]

        # Verify tree in memory rebuilt from sqlite
        tree_resp = client2.get("/api/tree")
        tree = tree_resp.json()
        assert tree["id"] == 50
        assert tree["left"]["id"] == 25
        assert tree["right"]["id"] == 75
