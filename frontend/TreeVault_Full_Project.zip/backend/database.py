import sqlite3
import os
from typing import List
from avl_tree import Student

DATABASE_PATH = os.getenv('DATABASE_URL', 'vidyavriksha.db')

def init_db():
    """Create the students table if it doesn't exist."""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            marks REAL NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def load_all_students() -> List[Student]:
    """Load all students from the database."""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT id, name, marks FROM students')
    rows = cursor.fetchall()
    conn.close()
    
    return [Student(id=row[0], name=row[1], marks=row[2]) for row in rows]

def save_student(student: Student):
    """Insert a student into the database."""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO students (id, name, marks) VALUES (?, ?, ?)',
        (student.id, student.name, student.marks)
    )
    conn.commit()
    conn.close()

def remove_student(student_id: int):
    """Delete a student from the database."""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM students WHERE id = ?', (student_id,))
    conn.commit()
    conn.close()

def clear_all_students():
    """Delete all students from the database."""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM students')
    conn.commit()
    conn.close()
